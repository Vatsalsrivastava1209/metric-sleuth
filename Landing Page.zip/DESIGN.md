# Design System Strategy: The Forensic Lens

## 1. Overview & Creative North Star
**Creative North Star: "The Digital Forensic Lab"**

This design system moves away from the "generic SaaS dashboard" to create a high-fidelity, cinematic environment for Root Cause Analysis (RCA). We are building a space that feels like a high-end command center—precise, authoritative, and deeply immersive.

To achieve this, we break the "template" look through **Intentional Asymmetry**. We do not use equal-width columns. Instead, we use a dominant "Primary Analysis" area balanced by a "Contextual Sidebar" of a different width. We leverage **Overlapping Glass Layers** to create a sense of physical depth, where data feels like it is projected onto panels rather than simply printed on a screen. The high-contrast typography scale (moving from massive `display-lg` numbers to microscopic `label-sm` technical metadata) mirrors the way a detective moves from a "birds-eye view" to a "microscopic detail."

---

## 2. Colors & Surface Philosophy
The palette is rooted in a "Deep Dark" spectrum, using the `#0a0e17` to `#31343f` range to define importance rather than using lines.

### The "No-Line" Rule
Prohibit 1px solid borders for sectioning large layout blocks. Boundaries must be defined solely through background color shifts. A `surface-container-low` section sitting on a `surface` background is enough to define a zone. 

### Surface Hierarchy & Nesting
Treat the UI as a series of nested physical layers:
*   **Base Layer:** `surface` (#10131d) — The "floor" of the application.
*   **Structural Panels:** `surface-container-low` (#181b25) — Large layout regions.
*   **Interactive Cards:** `surface-container` (#1c1f29) — Floating interactive elements.
*   **Active Overlays:** `surface-container-highest` (#31343f) — Modals and popovers.

### The "Glass & Gradient" Rule
To move beyond a flat UI, floating elements must use **Glassmorphism**. Apply `surface-container-high` at 70% opacity with a `20px` backdrop-blur. 
*   **Signature Textures:** Use a subtle linear gradient for Primary CTAs: `primary` (#c3f5ff) to `primary-container` (#00e5ff) at a 135° angle. This adds a "glow" that feels powered by the data itself.

---

## 3. Typography: The Editorial Scale
We use typography to distinguish between "Human Narrative" and "Machine Data."

*   **Human Narrative (Inter):** Used for Headlines and Body. It should feel clean and geometric.
    *   *Display-LG (3.5rem):* Used for hero metrics (e.g., "99.9% Uptime").
    *   *Headline-SM (1.5rem):* Used for incident titles.
*   **Machine Data (JetBrains Mono/Space Grotesk):** We substitute the standard label font with `spaceGrotesk` and mono fonts for technical readouts.
    *   *Label-MD (0.75rem):* Used for timestamps, error codes, and terminal outputs.
*   **Hierarchy Tip:** Pair a `display-md` metric in `primary` color with a `label-sm` description in `on-surface-variant`. This creates a sophisticated, data-dense look found in premium financial terminals.

---

## 4. Elevation & Depth
Depth is achieved through **Tonal Layering** rather than traditional drop shadows.

*   **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section. This creates a soft "sunken" or "raised" effect without visual clutter.
*   **Ambient Shadows:** For floating modals, use a "Cyan Glow" shadow instead of black. 
    *   *Values:* `0px 20px 40px rgba(0, 229, 255, 0.08)`. This mimics the light emitted from a futuristic screen.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility, use the `outline-variant` token at **15% opacity**. Never use 100% opaque borders for decorative containment.
*   **Depth through Blur:** Use a `12px` blur on any surface that overlaps a chart or data visualization to maintain legibility while preserving the "layered" aesthetic.

---

## 5. Components

### Buttons & Interaction
*   **Primary:** Gradient fill (`primary` to `primary_container`). No border. `md` (0.375rem) roundedness.
*   **Secondary:** Ghost style. `outline-variant` (20% opacity) border with `on-surface` text.
*   **AI Action (Purple):** Use `secondary_container` (#442bb5) with a subtle `secondary` pulse animation to indicate "AI is thinking."

### Input Fields & Data Entry
*   **The "Terminal" Input:** No background color on idle. Only an `outline-variant` bottom border. On focus, the background transitions to `surface-container-high` with a `primary` 1px left-accent bar.

### Cards & Lists
*   **No Dividers:** Forbid the use of `1px` lines between list items. Use a `12` (3rem) spacing gap or a subtle background hover shift (`surface-variant`) to separate content.
*   **The Forensic Card:** A `surface-container` background with an `xl` (0.75rem) corner radius. Use `primary-fixed-dim` for small data accents in the top-right corner.

### Specialized RCA Components
*   **The "Spike" Indicator:** Using the `emerald` accent, create a micro-sparkline that sits within a `label-sm` badge.
*   **The "Root Cause" Node:** A glass-morphic container using `secondary-container` (Purple) to highlight AI-generated insights.

---

## 6. Do's and Don'ts

### Do:
*   **Use Asymmetric Spacing:** Give more "breathing room" (`16` or `20` scale) to the top and left of headers to create an editorial layout.
*   **Embrace High Contrast:** Keep technical data in `on-surface-variant` and critical insights in `primary` or `error`.
*   **Layer Surfaces:** Always ask, "Can I define this area with a background shift instead of a line?"

### Don't:
*   **Don't use "Pure" Gray:** Every neutral must be tinted with the background's deep navy/blue hue to maintain the "Deep Dark" atmosphere.
*   **Don't over-round:** Avoid `full` rounded corners for functional UI; keep to the `md` (0.375rem) and `lg` (0.5rem) scale to maintain a professional, sharp-edged futuristic feel.
*   **Don't use standard shadows:** Never use a default `0,0,0,0.5` shadow. It will look muddy on a `#060912` background. Use tinted ambient glows.